# Introducción de JS para React

Si quieren ejecutar el programa, deben de reconstruir los módulos de node, para eso ejecuten el siguiente comando en la carpeta del proyecto

```
npm install
```